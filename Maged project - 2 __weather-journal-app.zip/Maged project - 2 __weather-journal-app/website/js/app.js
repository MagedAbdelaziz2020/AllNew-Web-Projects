/* Global Variables */
//api.openweathermap.org/data/2.5/weather?zip={zip code}&appid={API key}

const LinkURL = "http://api.openweathermap.org/data/2.5/weather?zip=" ;
const apikey = "fca54ba7aacfc90eadb86f7542ed078c"
const units = "metric"
//input values
const feeling = document.getElementById('feelings');
const zipInput = document.getElementById('zip');

//output values
const tempDiv = document.getElementById("temp");
const contentDiv = document.getElementById("content");
const dateDiv = document.getElementById("date");
//create a new date instance dynamicall with js
let d = new Date();
// take care that getmonth() counts month from 0 to 11 
let newDate = d.getMonth()+ 1 +'.'+ d.getDate()+'.'+ d.getFullYear();


const getData = async () => {
    //code to fetch data from api ( await the fetch )
    //---------> fetch(`${LinkURL}${zipInput.value}&appid=${apikey}&${units}`);
  
     const request = await fetch(`${LinkURL}${zipInput.value}&appid=${apikey}&${units}`);
     try{
        // code to convert json data and return result ( await conversion )
        const response = await request.json();
        return response;
     } catch (error) {
         console.log(error)
     }
 };
 
 /* Function to POST data */
 // Async POST
const postData = async ( url = '', data = {})=>{

    const response = await fetch(url, {
    method: 'POST', 
    credentials: 'same-origin', 
    headers: {
        'Content-Type': 'application/json',
    },
    body: JSON.stringify(data), // body data type must match "Content-Type" header        
  });

    try {
      const newData = await response.json();
      return newData;
    }catch(error) {
    console.log("error", error);
    }
};

// Async GET
const retrieveData = async (url='') =>{ 
  const request = await fetch(url);
  try {
  // Transform into JSON
  const allData = await request.json()
  }
  catch(error) {
    console.log("error", error);
    // appropriately handle the error
  }
};


   document.getElementById("generate").addEventListener('click',performAction )
   function performAction (e) {
      e.preventDefault() 
      
      const newZip = document.getElementById('zip').value;
      const newFeeling = document.getElementById('feelings').value;

      getData (`${LinkURL}${zipInput.value}&appid=${apikey}&${units}`)
      .then(function (sendData) { 
          console.log(sendData)
         postData ('/add' ,{
              date: Date.d,
              temp: tempDiv.temp,   //data   or  tempDiv
              content: content,
            });
          }) 
     // updateUi('/all') /**'/all' */
  // New Syntax!
  
 /* .then(function(data){ //**data 
      //add data
    console.log(data);
    postData('/project', {
         date: Date.d,
         temp: tempDiv.temp,
         content: content,
      });
  })
  */
  .then(
    updateUI('/all')
   )
  }
  const updateUI = async () => {
    const request = await fetch('all');  //'all'
    try{
      const allData = await request.json();
     document.getElementById("temp").innerHTML = allData[0].temp;
     document.getElementById("date").innerHTML = allData[0].date;
     document.getElementById("content").innerHTML = allData[0].content;
    }catch(error){
      console.log("error", error);
    }
  }